﻿namespace ImageProcessingPractice
{
    using IronOcr;

    public static class MyOcr
    {
        static MyOcr()
        {
            AdvOcr = SetAdvOcrConfigs();
        }

        public static AdvancedOcr AdvOcr { get; private set; }

        private static AdvancedOcr SetAdvOcrConfigs()
        {
            var advOcr = new AdvancedOcr
            {
                CleanBackgroundNoise = false,
                ColorDepth = 4,
                ColorSpace = AdvancedOcr.OcrColorSpace.Color,
                EnhanceContrast = false,
                DetectWhiteTextOnDarkBackgrounds = false,
                RotateAndStraighten = false,
                Language = IronOcr.Languages.English.OcrLanguagePack,
                EnhanceResolution = false,
                InputImageType = AdvancedOcr.InputTypes.Document,
                ReadBarCodes = true,
                Strategy = AdvancedOcr.OcrStrategy.Fast
            };

            return advOcr;
        }
    }
}
